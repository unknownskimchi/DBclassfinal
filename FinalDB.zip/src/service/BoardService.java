package service;

import java.sql.Connection;
import java.util.ArrayList;

import dao.BoardDAO;
import db.DBConn;
import vo.Board;

public class BoardService {
   private static BoardService service = new BoardService();
   private BoardService() {}
   public static BoardService getInstance() {
      return service;
   }
   
   public int getCount() {
      Connection con = DBConn.getMySqlConnection();
      BoardDAO dao = BoardDAO.getInstance();
      dao.setConnection(con);
      try {
         int cnt = dao.getCount();
         return cnt;
      } catch (Exception e) {
         // TODO: handle exception
         System.out.println("getCount Exception");
      }
         return 0;
   }
   
   public ArrayList<Board> getList(int currentPage, int pageSize){
      Connection con = DBConn.getMySqlConnection();
      BoardDAO dao = BoardDAO.getInstance();
      dao.setConnection(con);
      
      int startNo = (currentPage - 1) * pageSize + 1;
      int goSize = ((startNo -1)/10 +1) * 10; 
      ArrayList<Board> list = null;
      
      try {
         list = dao.getList(startNo, goSize);
         
         for(Board vo : list) {
            vo.setReplyCount(ReplyService.getInstance().getCount(vo.getIdx()));
         }
      } catch (Exception e) {
         System.out.println("getList Exception");
      }
      
      DBConn.close(con);
      return list;
   }
   
   public void insert(Board vo) {
      Connection con = DBConn.getMySqlConnection();
      BoardDAO dao = BoardDAO.getInstance();
      dao.setConnection(con);
      
      try {
         dao.insert(vo);
         
      } catch (Exception e) {
         // TODO: handle exception
         e.printStackTrace();
      }
      
      
      
      DBConn.close(con);
   }
   
   public Board getSelectOne(int idx) {
      Connection con = DBConn.getMySqlConnection();
      BoardDAO dao = BoardDAO.getInstance();
      dao.setConnection(con);
      
      Board vo = null;
      
      try {
         vo = dao.getSelectOne(idx);
      } catch (Exception e) {
         // TODO: handle exception
         System.out.println("getSelectOne Exception");
         e.printStackTrace();
      }
      DBConn.close(con);
      return vo;
   }
   
   public void readCount(int idx) {
      Connection con = DBConn.getMySqlConnection();
      BoardDAO dao = BoardDAO.getInstance();
      dao.setConnection(con);
      
      try {
         dao.readCount(idx);
      } catch (Exception e) {
         // TODO: handle exception
         System.out.println("readCount Exception");
         e.printStackTrace();
      }
      DBConn.close(con);
   }
   
   public void update(Board vo) {
      Connection con = DBConn.getMySqlConnection();
      BoardDAO dao = BoardDAO.getInstance();
      dao.setConnection(con);
      
      try {
         dao.update(vo);
      } catch (Exception e) {
         // TODO: handle exception
         System.out.println("update Exception");
         e.printStackTrace();
      }
      
      DBConn.close(con);
   }
   
   public boolean isPassword(int idx, String password) {
      Connection con = DBConn.getMySqlConnection();
      BoardDAO dao = BoardDAO.getInstance();
      dao.setConnection(con);
      
      boolean result = false;
      
      try {
         result = dao.isPassword(idx, password);
      } catch (Exception e) {
         // TODO: handle exception
         System.out.println("password check Exception");
         e.printStackTrace();
      }
      
      return result;
   }
   
   public void delete(int idx) {
      Connection con = DBConn.getMySqlConnection();
      BoardDAO dao = BoardDAO.getInstance();
      dao.setConnection(con);
      
      try {
         dao.delete(idx);
      } catch (Exception e) {
         // TODO: handle exception
         System.out.println("delete Exception");
         e.printStackTrace();
      }
      
      DBConn.close(con);
   }
   
   
   
   
   
   
   
   
}