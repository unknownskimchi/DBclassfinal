package service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import dao.ReplyDAO;
import db.DBConn;
import vo.Reply;

public class ReplyService {
   private static ReplyService service = new ReplyService();
   private ReplyService() {}
   public static ReplyService getInstance() {
      return service;
   }
   
   
   //댓글 수정
   public boolean update(Reply vo) {
      Connection con = DBConn.getMySqlConnection();
      ReplyDAO dao = ReplyDAO.getInstance();
      dao.setConnection(con);
      
      boolean flag = false;
      try {
         Reply res = dao.getOne(vo.getIdx());
         if(res.getPassword().equals(vo.getPassword())) {
            dao.update(vo);
            flag = true;
         }
      } catch (SQLException e) {
         e.printStackTrace();
      }
      DBConn.close(con);
      return flag;
   }
   
   
   
   public boolean delete(int idx, String password) {
      Connection con = DBConn.getMySqlConnection();
      ReplyDAO dao = ReplyDAO.getInstance();
      dao.setConnection(con);
      
      boolean flag = false;
      try {
         Reply res = dao.getOne(idx);
         if(res.getPassword().equals(password)) {
            dao.delete(idx);
            flag = true;
         }
      } catch (Exception e) {
         // TODO: handle exception
         e.printStackTrace();
      }
      
      DBConn.close(con);
      return flag;
   }
   
   
   public void insert(Reply vo) {
      Connection con = DBConn.getMySqlConnection();
      ReplyDAO dao = ReplyDAO.getInstance();
      dao.setConnection(con);
      
      try {
         dao.insert(vo);
      } catch (Exception e) {
         // TODO: handle exception
         e.printStackTrace();
      }
      
      DBConn.close(con);
      
   }
   
   public int getCount(int idx) {
      Connection con  = DBConn.getMySqlConnection();
      ReplyDAO dao = ReplyDAO.getInstance();
      dao.setConnection(con);
      
      int cnt = 0;
      
      try {
         cnt = dao.getCount(idx);
      } catch (Exception e) {
         // TODO: handle exception
         e.printStackTrace();
      }
      DBConn.close(con);
      return cnt;
      
   }
   
   public ArrayList<Reply> getList(int ref){
      ArrayList<Reply> list = null;
      Connection con = DBConn.getMySqlConnection();
      ReplyDAO dao = ReplyDAO.getInstance();
      dao.setConnection(con);
      
      try {
         list = dao.getList(ref);
      } catch (Exception e) {
         // TODO: handle exception
         e.printStackTrace();
      }
      
      DBConn.close(con);
      return list;
   }
   
   
   
}