package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import vo.Reply;


public class ReplyDAO {
   private static ReplyDAO dao = new ReplyDAO();
   private ReplyDAO(){}
   public static ReplyDAO getInstance(){
      return dao;
   }
   
   private Connection con;
   public void setConnection(Connection con) {
      this.con = con;
   }
   
   															//Reply 테이블의 idx 로 데이터 한 개 가져오기 : getOne()
   public Reply getOne(int idx) throws SQLException {
      Reply vo = new Reply();
      String sql="select * from Reply where idx = ?";
      PreparedStatement pstmt = con.prepareStatement(sql);
      pstmt.setInt(1, idx);
      ResultSet rs = pstmt.executeQuery();
      rs.next();
      
      vo.setIdx(rs.getInt("idx"));
      vo.setName(rs.getString("name"));
      vo.setPassword(rs.getString("password"));
      vo.setContent(rs.getString("content"));
      vo.setRdate(rs.getDate("rdate"));
      vo.setRef(rs.getInt("ref"));
      pstmt.close();   
      return vo;
   }
   
   public void update(Reply vo) throws SQLException{
      String sql="update Reply set name=?,content=? where idx=?";
      PreparedStatement pstmt = con.prepareStatement(sql);
      //sql 
      pstmt.setString(1, vo.getName());
      pstmt.setString(2, vo.getContent());
      pstmt.setInt(3, vo.getIdx());
      pstmt.execute();
      con.commit();
      pstmt.close();   
   }
   
   public void delete(int idx) throws SQLException{
      String sql = "delete from Reply where idx=?";
      PreparedStatement pstmt = con.prepareStatement(sql);
      //sql 파라미터 설정
      pstmt.setInt(1, idx);
      pstmt.execute();
      con.commit();
      pstmt.close();  
   }
   
   
   
   //댓글 추가
   public void insert(Reply vo) throws SQLException{
      String sql="insert into Reply(idx,name,password,content,ref) values (reply_idx_seq.nextval,?,?,?,?)";
      PreparedStatement pstmt = con.prepareStatement(sql);
      
      pstmt.setString(1,vo.getName());
      pstmt.setString(2, vo.getPassword());
      pstmt.setString(3, vo.getContent());
      pstmt.setInt(4, vo.getRef());
      pstmt.execute();
      con.commit();
      pstmt.close();   
   }
   
   
   
   public int getCount(int idx) throws SQLException{             //댓글의 갯수,리스트 구하기 : 특정 ref 값을 조건으로
	   
      String sql="select count(*) from Reply where ref=?";
      PreparedStatement pstmt = con.prepareStatement(sql);
      pstmt.setInt(1, idx);
      ResultSet rs = pstmt.executeQuery();
      int cnt=0;
      if(rs.next()){
      cnt = rs.getInt(1);
      }
      pstmt.close();   //pstmt가 null이면 Exception
      return cnt;
   }
   
   public ArrayList<vo.Reply> getList(int ref) throws SQLException {
      ArrayList<Reply> list = new ArrayList<>();
      
      String sql="select * from Reply where ref = ?";
      PreparedStatement pstmt = con.prepareStatement(sql);
      pstmt.setInt(1, ref);
      ResultSet rs = pstmt.executeQuery();
      
      if(rs.next()) {  
         do{
            Reply vo = new Reply();
            vo.setIdx(rs.getInt("idx"));
            vo.setRef(rs.getInt("ref"));
            vo.setName(rs.getString("name"));
            vo.setPassword(rs.getString("password"));
            vo.setContent(rs.getString("content"));
            vo.setRdate(rs.getDate("wdate"));
            list.add(vo);
         }while(rs.next());
      }
      pstmt.close();   
      return list;
   }
   
   
   
}



