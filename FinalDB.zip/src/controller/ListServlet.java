package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.plaf.synth.SynthSeparatorUI;

import org.apache.jasper.tagplugins.jstl.core.Out;

import service.BoardService;
import vo.Board;
import vo.Page;

@WebServlet("/list.do")
public class ListServlet extends HttpServlet {
   private static final long serialVersionUID = 1L;
       
    public ListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
      
      
      String temp = request.getParameter("page");
      int currentPage = 1;
      if(temp!= null) {
         currentPage = Integer.parseInt(temp);
      }
      
      int pageSize = 10;
      
      BoardService board = BoardService.getInstance();
      
      int totalCount = board.getCount();
      
      //PrintWriter out = response.getWriter();
   
      
      Page plist = new Page(currentPage, pageSize, totalCount);
      //System.out.println(totalCount);
   
      
      
      ArrayList<Board> list = board.getList(currentPage, pageSize);
      //System.out.println(list);
   
      int cnt = board.getCount();
      request.setAttribute("list", list);
      request.setAttribute("plist", plist);
      
      RequestDispatcher dispatcher = 
            request.getRequestDispatcher("/Board/listView.jsp");
      dispatcher.forward(request, response);

   }

   /**
    * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
    */
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      // TODO Auto-generated method stub
      doGet(request, response);
   }

}