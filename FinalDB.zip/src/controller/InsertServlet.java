package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.BoardService;
import vo.Board;

@WebServlet("/insert.do")
public class InsertServlet extends HttpServlet {
   private static final long serialVersionUID = 1L;
       
    public InsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         RequestDispatcher dispatcher 
         = request.getRequestDispatcher("/Board/insertView.jsp");
         dispatcher.forward(request, response);
      
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      request.setCharacterEncoding("UTF-8");

         String name=request.getParameter("name");
         String password = request.getParameter("password");
         String subject = request.getParameter("subject");
         String content = request.getParameter("content");
         String ip = request.getParameter("ip");
         
         //5개의 파라미터 저장한 값으로 insert sql 실행 
         
         BoardService board = BoardService.getInstance();
         // 1.Board 타입 객체 vo 생성
         Board vo = new Board();
         // 2.vo 객체 프로퍼티(멤버변수) 값을 전달받을 파라미터로 설정
         vo.setName(name);
         vo.setPassword(password);
         vo.setSubject(subject);
         vo.setContent(content);
         vo.setIp(ip);
         
         board.insert(vo);
         response.sendRedirect("list.do");
   }

}