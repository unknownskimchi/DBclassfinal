package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import service.BoardService;
import service.ReplyService;
import vo.Board;
import vo.Reply;

@WebServlet("/select.do")
public class SelectServlet extends HttpServlet {
   private static final long serialVersionUID = 1L;
       
    public SelectServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      int idx 
      = Integer.parseInt(request.getParameter("idx"));
      String exec = request.getParameter("exec");
      if(exec == null) exec="detail";
      //현재 페이지 파라미터 저장
      int currentPage = Integer.parseInt(request.getParameter("page"));
      
      
      //idx 값으로 검색
      BoardService board = BoardService.getInstance();
      if(exec.equals("detail")) {
         board.readCount(idx);  //글 상세보기 할 때 조회수 증가
         
         //읽은 글 idx 쿠키에 저장
         Cookie c = new Cookie("idx" + idx, String.valueOf(idx) );
         //name은 예) idx432 , value는 String 타입
         c.setMaxAge(24*60*60);
         response.addCookie(c);
         
         //board 테이블 idx 컬럼의 댓글리스트
         ReplyService reply = ReplyService.getInstance();
         ArrayList<Reply> clist = reply.getList(idx);
         request.setAttribute("clist", clist);
         
      }else if(exec.equals("reply")) {
         ReplyService reply = ReplyService.getInstance();
         ArrayList<Reply> clist = reply.getList(idx);
         request.setAttribute("clist", clist);
         exec="detail";   //페이지 이동하는 jsp 파일명
      }
         
      Board vo = board.getSelectOne(idx);  //1건 검색
      //상세보기,수정,삭제 jsp 페이지에서 모두 필요 값 vo
      request.setAttribute("rn", "\n");
      request.setAttribute("vo", vo);   
      request.setAttribute("page", currentPage);
      
      //pageContext.forward( exec + "View.jsp");
      RequestDispatcher dispatcher =
            request.getRequestDispatcher("/Board/" + exec + "View.jsp");
      
      dispatcher.forward(request, response);

   }

   
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      // TODO Auto-generated method stub
      doGet(request, response);
   }

}