package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.ReplyService;
import vo.Reply;

@WebServlet("/reply.do")
public class ReplyServlet extends HttpServlet {
   private static final long serialVersionUID = 1L;
       
    public ReplyServlet() {
        super();
    }

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      request.setCharacterEncoding("UTF-8");
      
      response.setContentType("text/html; charset=UTF-8");
      PrintWriter out = response.getWriter();
      
      //댓글 추가,수정,삭제 실행 선택 파라미터
      int exe = Integer.parseInt(request.getParameter("exe"));
      int idx = Integer.parseInt(request.getParameter("idx"));
      int ref = Integer.parseInt(request.getParameter("ref"));
      String name = request.getParameter("name");
      String password = request.getParameter("password");
      String content = request.getParameter("content");
      
      //
      int currentPage = Integer.parseInt(request.getParameter("page"));
      Reply vo = new Reply();
      vo.setIdx(idx);  //댓글 수정시 꼭 있어야함.
      vo.setRef(ref);
      vo.setContent(content);
      vo.setName(name);
      vo.setPassword(password);
      
      //insert
      ReplyService reply = ReplyService.getInstance();
      
      out.print("<script>");
      if(exe == 1) { //댓글 새로 추가
         reply.insert(vo);
      }else if(exe == 2) {  //댓글 수정
         boolean res = reply.update(vo); 
         if(res){
            //성공   
            out.print("alert('댓글 수정 완료!');");
         }else {//실패
            out.print("alert('글 비밀번호 오류!');");
         }
      }else {  //댓글 삭제(exe == 3)
         boolean res = reply.delete(idx, password);
         if(res){
            out.print("alert('댓글 삭제 완료!');");
         }else {
            out.print("alert('글 비밀번호 오류!');");
         }
      }
      out.print("location.href='select.do?idx=" + ref 
            + "&page=" + currentPage + "&exec=reply'");
      out.print("</script>");
   }
}