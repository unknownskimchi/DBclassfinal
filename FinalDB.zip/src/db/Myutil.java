package db;

import java.util.Calendar;
import java.util.Date;

public class Myutil {
	public static boolean isToday(Calendar wdate) {
		Calendar now = Calendar.getInstance();
		
		Date d = new Date();
		
		if(now.get(Calendar.YEAR) == wdate.get(Calendar.YEAR)
		&& now.get(Calendar.MONTH) == wdate.get(Calendar.MONTH)
		&& now.get(Calendar.DATE) == wdate.get(Calendar.DATE)
		){
			return true;
		}
		return false;
	}
}
