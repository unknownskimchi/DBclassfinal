package vo;

import java.util.Date;

public class Board{
   private int idx;
   private String name;
   private String password;
   private String subject;
   private String content;
   private int readCount;
   private Date wdate;
   private String ip;
   private int replyCount;
   
   public int getIdx() {
      return idx;
   }
   public void setIdx(int idx) {
      this.idx = idx;
   }
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public String getPassword() {
      return password;
   }
   public void setPassword(String password) {
      this.password = password;
   }
   public String getSubject() {
      return subject;
   }
   public void setSubject(String subject) {
      this.subject = subject;
   }
   public String getContent() {
      return content;
   }
   public void setContent(String content) {
      this.content = content;
   }
   public int getReadCount() {
      return readCount;
   }
   public void setReadCount(int readCount) {
      this.readCount = readCount;
   }
   public Date getWdate() {
      return wdate;
   }
   public void setWdate(Date wdate) {
      this.wdate = wdate;
   }
   public String getIp() {
      return ip;
   }
   public void setIp(String ip) {
      this.ip = ip;
   }
   public int getReplyCount() {
      return replyCount;
   }
   public void setReplyCount(int replyCount) {
      this.replyCount = replyCount;
   }
   @Override
   public String toString() {
      return "Board [idx=" + idx + ", name=" + name + ", password=" + password + ", subject=" + subject + ", content="
            + content + ", readCount=" + readCount + ", wdate=" + wdate + ", ip=" + ip + ", replyCount="
            + replyCount + "]";
   }
      
   
}
